
finalData.RData: Data used in runPrezCoattail.R
finalDataCandLevel.RData: Data used in runPrezCoattailCandLevel.R and genTables.R
gsFinal.RData: Data used in runSynthControlModel.R
gsNonPrezFinal.RData: Data used in runSynthControlModel.R
genTables.R: Creates Tables 2, G.10, G.11, and G.12
runSynthControlModel.R: Run models in the section "Capturing the Quota’s Impact", 						  Appendices B, C, and H
runPrezCoattail.R: Run models in section "Presidential Coattails", "Increasing the Quota’s 				  Bite",  Appendix D, and E
runPrezCoattailCandLevel.R: Run models in appendix F
