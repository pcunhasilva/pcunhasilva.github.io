library(stargazer)
library(reshape2)
# Load Data
load(file = '~/finalDataCandLevel.RData')

# Gen prezParty
fraPartyLevel$prezParty <- 0
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'La République En Marche!' & fraPartyLevel$year == 2017] <- 1
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'Socialist Party' & fraPartyLevel$year == 2012] <- 1
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'Rally for the Republic/Union for a Popular Movement/The Republicans' & fraPartyLevel$year == 2007] <- 1
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'Rally for the Republic/Union for a Popular Movement/The Republicans' & fraPartyLevel$year == 2002] <- 1
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'Rally for the Republic/Union for a Popular Movement/The Republicans' & fraPartyLevel$year == 1997] <- 1
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'Socialist Party' & fraPartyLevel$year == 1993] <- 1

# Gen runnerup
fraPartyLevel$runnerup <- 0
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'National Front' & fraPartyLevel$year == 2017] <- 1
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'Rally for the Republic/Union for a Popular Movement/The Republicans' & fraPartyLevel$year == 2012] <- 1
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'Socialist Party' & fraPartyLevel$year == 2007] <- 1
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'National Front' & fraPartyLevel$year == 2002] <- 1
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'Socialist Party' & fraPartyLevel$year == 1997] <- 1
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'Rally for the Republic/Union for a Popular Movement/The Republicans' & fraPartyLevel$year == 1993] <- 1


# Gen prezPartyFem
fraPartyLevel$prezPartyFem <- as.numeric(fraPartyLevel$prezParty == 1 & fraPartyLevel$fem == 1)

# Gen runnerupFem
fraPartyLevel$runnerupFem <- as.numeric(fraPartyLevel$runnerup == 1 & fraPartyLevel$fem == 1)

# Get Districts where the runner up nominated a women
runnerupFem <- unique(fraPartyLevel[fraPartyLevel$runnerupFem == 1, c('dc', 'year', 'runnerupFem')])

# Gen winnerFem 
fraPartyLevel$winnerFem <- as.numeric(fraPartyLevel$winner == 1 & fraPartyLevel$fem == 1)

# Gen winnerPrezPartyFem 
fraPartyLevel$winnerPrezPartyFem <- as.numeric(fraPartyLevel$prezParty == 1 & fraPartyLevel$winner == 1 & fraPartyLevel$fem == 1)

# District Where the Prez Party nominated a women
distFemPrez <- unique(fraPartyLevel[fraPartyLevel$prezPartyFem == 1, c('year', 'dc')])
distFemPrez$distFemPrez  <- 1
fraPartyLevel <- merge(fraPartyLevel, distFemPrez, by = c('year', 'dc'), all.x = TRUE)
fraPartyLevel$distFemPrez[is.na(fraPartyLevel$distFemPrez)] <- 0

# Gen winnerNotPrezPartyFem (Prez party nominated a woman, winner is not from prez party, and it is a woman)
fraPartyLevel$winnerNotPrezPartyFem <- as.numeric(fraPartyLevel$distFemPrez == 1 & fraPartyLevel$prezParty == 0 & fraPartyLevel$winner == 1 & fraPartyLevel$fem == 1)

# Nominated Female per year
nominated <- aggregate(fraPartyLevel$fem, list(year = fraPartyLevel$year), FUN = sum, na.rm = TRUE)
names(nominated)[2] <- 'nominated'

# Nominated Female by prezParty per year
nominatedPrez <- aggregate(fraPartyLevel$prezPartyFem, list(year = fraPartyLevel$year), FUN = sum, na.rm = TRUE)
names(nominatedPrez)[2] <- 'nominatedPrez'

# Woman won
won <- aggregate(fraPartyLevel$winnerFem, list(year = fraPartyLevel$year), FUN = sum, na.rm = TRUE)
names(won)[2] <- 'won'

# Woman won (from presidential party)
wonPrez <- aggregate(fraPartyLevel$winnerPrezPartyFem, list(year = fraPartyLevel$year), FUN = sum, na.rm = TRUE)
names(wonPrez)[2] <- 'wonPrez'

# Woman won (not from presidential party)
wonNotPrez <- aggregate(fraPartyLevel$winnerNotPrezPartyFem, list(year = fraPartyLevel$year), FUN = sum, na.rm = TRUE)
names(wonNotPrez)[2] <- 'wonNotPrez'

# Number of Different parties for women won
table(fraPartyLevel$partyname[fraPartyLevel$winnerNotPrezPartyFem == 1], fraPartyLevel$year[fraPartyLevel$winnerNotPrezPartyFem == 1])

# Table 2:Combine Everything 
all <- cbind(as.character(nominatedPrez[, 1]), nominatedPrez[, -1], wonPrez[, -1]
	, round(wonPrez[, -1]/nominatedPrez[, -1], 3) * 100
	, round(wonNotPrez[, -1]/nominatedPrez[, -1], 3) * 100)
colnames(all) <- c('year', 'N of Women Running', 'N of Women Elected', '% of Elected', '% of Losses to Another Woman')
stargazer(all, summary = FALSE)

# Table G.10: Generate % of nominated women by party and year
fraPartyLevel$x <- 1
nCand <- ddply(fraPartyLevel[fraPartyLevel$partyname %in% c('National Front', 'Rally for the Republic/Union for a Popular Movement/The Republicans'
	, 'Socialist Party', 'La République En Marche!'), ], .variables = c('year', 'partyname'), .fun = summarise
		, nCand = sum(x)
		, nFem = sum(fem))
nCand$pctFem <- round((nCand$nFem/nCand$nCand) * 100, 3)
out <- dcast(nCand, partyname ~ year)
stargazer::stargazer(out, summary = FALSE)

# Table G.11: Generate % of nominated women by ideology
table(fraPartyLevel$partyname, fraPartyLevel$ideology)
fraPartyLevel$x <- 1
nCand <- ddply(fraPartyLevel, .variables = c('year', 'ideology'), .fun = summarise
	, nCand = sum(x)
	, nFem = sum(fem))
nCand$pctFem <- round((nCand$nFem/nCand$nCand) * 100, 3)
out <- dcast(nCand, ideology ~ year)
stargazer::stargazer(out, summary = FALSE)

# List Parties by Ideology - Table G.12
stargazer::stargazer(unique(fraPartyLevel[,c('partyname', 'ideology')]), summary = FALSE)
