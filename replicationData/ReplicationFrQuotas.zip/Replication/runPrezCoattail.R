rm(list = ls())

library(multiwayvcov)
library(lmtest)
library(stargazer)
library(lfe)
library(mvtnorm)

# Load Data
load(file = '~/finalData.RData')

# Table D.4: Run Main Model 
m1 <- glm(winFem ~ prezParty * yearF
		+ femDef	
		+ maleNotDef			
		+ femNotDef
		+ pct_fem		
		+ liberal
		+ comp
		+ left
		+ center_left
		+ center 
		+ center_right
		+ right
	, data = fraDistLevel
	, family = 'binomial'
	)
coeftest(m1, vcov. = cluster.vcov(m1, fraDistLevel$dc))
se1 = sqrt(diag(cluster.vcov(m1, fraDistLevel$dc)))
stargazer::stargazer(m1
	, se = list(se1)
	, no.space = TRUE
	, single.row = TRUE
	, order = c(1, 2, 3, 4, 5, 6, 23, 24, 25, 26, 27)
	, covariate.labels = c('Presidential Coattails'
		, '1997 Election'
		, '2002 Election'
		, '2007 Election'
		, '2012 Election'
		, '2017 Election'
		, 'Presidential Coattails X 1997'
		, 'Presidential Coattails X 2002'
		, 'Presidential Coattails X 2007'
		, 'Presidential Coattails X 2012'
		, 'Presidential Coattails X 2017'		
		, 'Female Incumbent is Defending'
		, 'Male Incumbent is Not Defending'		
		, 'Female Incumbent is Not Defending'		
		, '% of Female Candidates'	
		, '% of Leftist Voters'
		, 'Competitiveness'
		, 'Left did not enter'
		, 'Left nominated at least one woman'
		, 'Center-Left did not enter'
		, 'Center-Left nominated at least one woman'
		, 'Center did not enter'
		, 'Center nominated at least one woman'
		, 'Center-Right did not enter'
		, 'Center-Right nominated at least one woman'
		, 'Right did not enter'
		, 'Right nominated at least one woman')
	, dep.var.labels = 'A Woman Wins the District'
	, star.cutoffs = c(0.05, 0.01, 0.001)
	, title = c('Presidential Coattails and Female Representation--France Legislative Elections, 1993-2017')
	, label = 'tab:prezCoat'
	)

### Figure 3:
# Run simulations
set.seed(123)
sims <- rmvnorm(10000, mean = coef(m1), sigma = cluster.vcov(m1, fraDistLevel$dc))
# Generate Scenarios
xValuesBase <- cbind(
	intercept = 1,
	prezParty = 0,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m1)$femDef),	
	maleNotDef  = median(model.frame(m1)$maleNotDef),
	femNotDef = median(model.frame(m1)$femNotDef),
	pct_fem = median(model.frame(m1)$pct_fem),
	liberal = median(model.frame(m1)$liberal),
	comp = median(model.frame(m1)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 
	prezParty1997 = 0,
	prezParty2002 = 0,
	prezParty2007 = 0,
	prezParty2012 = 0,
	prezParty2017 = 0
	)
xValues93 <- cbind(
	intercept = 1,
	prezParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m1)$femDef),	
	maleNotDef  = median(model.frame(m1)$maleNotDef),
	femNotDef = median(model.frame(m1)$femNotDef),
	pct_fem = median(model.frame(m1)$pct_fem),
	liberal = median(model.frame(m1)$liberal),
	comp = median(model.frame(m1)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	prezParty1997 = 0,
	prezParty2002 = 0,
	prezParty2007 = 0,
	prezParty2012 = 0,
	prezParty2017 = 0
	)
xValues97 <- cbind(
	intercept = 1,
	prezParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m1)$femDef),	
	maleNotDef  = median(model.frame(m1)$maleNotDef),
	femNotDef = median(model.frame(m1)$femNotDef),
	pct_fem = median(model.frame(m1)$pct_fem),
	liberal = median(model.frame(m1)$liberal),
	comp = median(model.frame(m1)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	prezParty1997 = 1,
	prezParty2002 = 0,
	prezParty2007 = 0,
	prezParty2012 = 0,
	prezParty2017 = 0
	)
xValues02 <- cbind(
	intercept = 1,
	prezParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m1)$femDef),	
	maleNotDef  = median(model.frame(m1)$maleNotDef),
	femNotDef = median(model.frame(m1)$femNotDef),
	pct_fem = median(model.frame(m1)$pct_fem),
	liberal = median(model.frame(m1)$liberal),
	comp = median(model.frame(m1)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	prezParty1997 = 0,
	prezParty2002 = 1,
	prezParty2007 = 0,
	prezParty2012 = 0,
	prezParty2017 = 0
	)
xValues07 <- cbind(
	intercept = 1,
	prezParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m1)$femDef),	
	maleNotDef  = median(model.frame(m1)$maleNotDef),
	femNotDef = median(model.frame(m1)$femNotDef),
	pct_fem = median(model.frame(m1)$pct_fem),
	liberal = median(model.frame(m1)$liberal),
	comp = median(model.frame(m1)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	prezParty1997 = 0,
	prezParty2002 = 0,
	prezParty2007 = 1,
	prezParty2012 = 0,
	prezParty2017 = 0
	)
xValues12 <- cbind(
	intercept = 1,
	prezParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m1)$femDef),	
	maleNotDef  = median(model.frame(m1)$maleNotDef),
	femNotDef = median(model.frame(m1)$femNotDef),
	pct_fem = median(model.frame(m1)$pct_fem),
	liberal = median(model.frame(m1)$liberal),
	comp = median(model.frame(m1)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	prezParty1997 = 0,
	prezParty2002 = 0,
	prezParty2007 = 0,
	prezParty2012 = 1,
	prezParty2017 = 0
	)
xValues17 <- cbind(
	intercept = 1,
	prezParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m1)$femDef),	
	maleNotDef  = median(model.frame(m1)$maleNotDef),
	femNotDef = median(model.frame(m1)$femNotDef),
	pct_fem = median(model.frame(m1)$pct_fem),
	liberal = median(model.frame(m1)$liberal),
	comp = median(model.frame(m1)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	prezParty1997 = 0,
	prezParty2002 = 0,
	prezParty2007 = 0,
	prezParty2012 = 0,
	prezParty2017 = 1
	)
# Calculate linear predictor
rBase <- sims %*% t(xValuesBase)
r93 <- sims %*% t(xValues93)
r97 <- sims %*% t(xValues97)
r02 <- sims %*% t(xValues02)
r07 <- sims %*% t(xValues07)
r12 <- sims %*% t(xValues12)
r17 <- sims %*% t(xValues17)

# Calculate Pr
pBase <- plogis(rBase)
p93 <- plogis(r93)
p97 <- plogis(r97)
p02 <- plogis(r02)
p07 <- plogis(r07)
p12 <- plogis(r12)
p17 <- plogis(r17)

# Get quantities
qBase <- quantile(pBase, probs = c(0.025, 0.5, 0.975))
q93 <- quantile(p93 - pBase, probs = c(0.025, 0.5, 0.975))
q97 <- quantile(p97 - pBase, probs = c(0.025, 0.5, 0.975))
q02 <- quantile(p02 - pBase, probs = c(0.025, 0.5, 0.975))
q07 <- quantile(p07 - pBase, probs = c(0.025, 0.5, 0.975))
q12 <- quantile(p12 - pBase, probs = c(0.025, 0.5, 0.975))
q17 <- quantile(p17 - pBase, probs = c(0.025, 0.5, 0.975))

pdf('~/prCoatTail.pdf', width = 10, height = 6)
par(mar = c(5, 8, 2, 2))
plot(y = c(q93[2], q97[2], q02[2], q07[2], q12[2], q17[2])
	, x = c(1993, 1997, 2002, 2007, 2012, 2017)
	, xlim = c(1992, 2018)
	, ylim = c(-0.1, 0.8)
	, type = 'p'
	, pch = 20
	, xlab = 'Election Year'
	, ylab = 'Difference Pr that a Women is Elected: \n Presidential Coattails - No Presidential Coattails'
	, cex.lab = 1.5
	, cex = 1.5
	, axes = FALSE)
axis(1, at = c(1993, 1997, 2002, 2007, 2012, 2017), tick = FALSE, cex.axis = 1.5)
axis(2, at = seq(-0.1, 0.8, 0.1), tick = TRUE, cex.axis = 1.1)
qs <- list(q93, q97, q02, q07, q12, q17)
years <- c(1993, 1997, 2002, 2007, 2012, 2017)
for(i in 1:6){
	lines(x = c(years[i], years[i]), y = c(qs[[i]][1], qs[[i]][3]))	
}
abline(h = 0, lty = 2)
dev.off()

############### Robustness Checks ################

# Table E.5: Run General Model + DC FEs
m2 <- glm(winFem ~ prezParty * yearF
		+ femDef	
		+ maleNotDef			
		+ femNotDef
		+ pct_fem		
		+ liberal
		+ comp
		+ left
		+ center_left
		+ center 
		+ center_right
		+ right		
		+ as.factor(dc)
	, data = fraDistLevel
	, family = 'binomial'
	)
se2 = sqrt(diag(cluster.vcov(m2, fraDistLevel$dc)))
stargazer::stargazer(m2
	, se = list(se2)
	, no.space = TRUE
	, single.row = TRUE
	, order = c(1, 2, 3, 4, 5, 6, 632, 633, 634, 635, 636)
	, covariate.labels = c('Presidential Coattail'
		, '1997 Election'
		, '2002 Election'
		, '2007 Election'
		, '2012 Election'
		, '2017 Election'
		, 'Presidential Coattails X 1997'
		, 'Presidential Coattails X 2002'
		, 'Presidential Coattails X 2007'
		, 'Presidential Coattails X 2012'
		, 'Presidential Coattails X 2017'		
		, 'Female Incumbent is Defending'
		, 'Male Incumbent is Not Defending'		
		, 'Female Incumbent is Not Defending'		
		, '% of Female Candidates'	
		, '% of Leftist Voters'
		, 'Competitiveness'
		, 'Left did not enter'
		, 'Left nominated at least one woman'
		, 'Center-Left did not enter'
		, 'Center-Left nominated at least one woman'
		, 'Center did not enter'
		, 'Center nominated at least one woman'
		, 'Center-Right did not enter'
		, 'Center-Right nominated at least one woman'
		, 'Right did not enter'
		, 'Right nominated at least one woman')
	, omit = 'dc'
	, add = list(c('District FE', 'Yes'))
	, dep.var.labels = 'A Woman is Elected'
	, star.cutoffs = c(0.05, 0.01, 0.001)
	, title = c('Presidential Coattails and Female Representation--France Legislative Elections, 1993-2017 with District FE')
	, label = 'tab:prezCoat'
	)


# Table E.6: Run General Model + DC FEs
m3 <- felm(winFem ~ prezParty * yearF
		+ femDef	
		+ maleNotDef			
		+ femNotDef
		+ pct_fem		
		+ liberal
		+ comp
		+ left
		+ center_left
		+ center 
		+ center_right
		+ right		
		| dc | 0 |  dc
	, data = fraDistLevel
	)
stargazer::stargazer(m3
	, no.space = TRUE
	, single.row = TRUE
	, order = c(1, 2, 3, 4, 5, 6, 23, 24, 25, 26, 27)
	, covariate.labels = c('Presidential Coattail'
		, '1997 Election'
		, '2002 Election'
		, '2007 Election'
		, '2012 Election'
		, '2017 Election'
		, 'Presidential Coattails X 1997'
		, 'Presidential Coattails X 2002'
		, 'Presidential Coattails X 2007'
		, 'Presidential Coattails X 2012'
		, 'Presidential Coattails X 2017'		
		, 'Female Incumbent is Defending'
		, 'Male Incumbent is Not Defending'		
		, 'Female Incumbent is Not Defending'		
		, '% of Female Candidates'	
		, '% of Leftist Voters'
		, 'Competitiveness'
		, 'Left did not enter'
		, 'Left nominated at least one woman'
		, 'Center-Left did not enter'
		, 'Center-Left nominated at least one woman'
		, 'Center did not enter'
		, 'Center nominated at least one woman'
		, 'Center-Right did not enter'
		, 'Center-Right nominated at least one woman'
		, 'Right did not enter'
		, 'Right nominated at least one woman')
	, omit = 'dc'
	, dep.var.labels = 'A Woman is Elected'
	, star.cutoffs = c(0.05, 0.01, 0.001)
	, add = list(c('District FE', 'Yes'))
	, title = c('Presidential Coattails and Female Representation--France Legislative Elections, 1993-2017  with District FE (Linear Model)')
	, label = 'tab:prezCoat'
	)

#-------------- Table and Figure -------------#
# Table E.7: Run for Runner Up
m4 <- glm(winFem ~ (runnerupFem) * yearF
		+ femDef	
		+ maleNotDef			
		+ femNotDef
		+ pct_fem		
		+ liberal
		+ comp
		+ left
		+ center_left
		+ center 
		+ center_right
		+ right		
	, data = fraDistLevel
	, family = 'binomial'
	)
summary(m4)
se4 = sqrt(diag(cluster.vcov(m4, fraDistLevel$dc)))

stargazer::stargazer(m4
	, no.space = TRUE
	, se = list(se4)
	, single.row = TRUE
	, order = c(1, 2, 3, 4, 5, 6, 23, 24, 25, 26, 27)
	, covariate.labels = c('Runner up Coattails'
		, '1997 Election'
		, '2002 Election'
		, '2007 Election'
		, '2012 Election'
		, '2017 Election'
		, 'Runner up Coattails X 1997'
		, 'Runner up Coattails X 2002'
		, 'Runner up Coattails X 2007'
		, 'Runner up Coattails X 2012'
		, 'Runner up Coattails X 2017'		
		, 'Female Incumbent is Defending'
		, 'Male Incumbent is Not Defending'		
		, 'Female Incumbent is Not Defending'		
		, '% of Female Candidates'	
		, '% of Leftist Voters'
		, 'Competitiveness'
		, 'Left did not enter'
		, 'Left nominated at least one woman'
		, 'Center-Left did not enter'
		, 'Center-Left nominated at least one woman'
		, 'Center did not enter'
		, 'Center nominated at least one woman'
		, 'Center-Right did not enter'
		, 'Center-Right nominated at least one woman'
		, 'Right did not enter'
		, 'Right nominated at least one woman')		
	, dep.var.labels = 'Woman is elected'
	, star.cutoffs = c(0.05, 0.01, 0.001)
	, title = c('Runner Up  Coattail and Female Representation--France Legislative Elections, 1993-2017  with District FE (Linear Model)')
	, label = 'tab:runCoat'
	)

## Figure 4
# Run simulations
set.seed(123)
sims <- rmvnorm(10000, mean = coef(m4), sigma = cluster.vcov(m4, fraDistLevel$dc))
# Generate Scenarios
xValuesBase <- cbind(
	intercept = 1,
	runnerParty = 0,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m4)$femDef),	
	maleNotDef  = median(model.frame(m4)$maleNotDef),
	femNotDef = median(model.frame(m4)$femNotDef),
	pct_fem = median(model.frame(m4)$pct_fem),
	liberal = median(model.frame(m4)$liberal),
	comp = median(model.frame(m4)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	runnerParty1997 = 0,
	runnerParty2002 = 0,
	runnerParty2007 = 0,
	runnerParty2012 = 0,
	runnerParty2017 = 0
	)

xValues93 <- cbind(
	intercept = 1,
	runnerParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m4)$femDef),	
	maleNotDef  = median(model.frame(m4)$maleNotDef),
	femNotDef = median(model.frame(m4)$femNotDef),
	pct_fem = median(model.frame(m4)$pct_fem),
	liberal = median(model.frame(m4)$liberal),
	comp = median(model.frame(m4)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	runnerParty1997 = 0,
	runnerParty2002 = 0,
	runnerParty2007 = 0,
	runnerParty2012 = 0,
	runnerParty2017 = 0
	)
xValues97 <- cbind(
	intercept = 1,
	runnerParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m4)$femDef),	
	maleNotDef  = median(model.frame(m4)$maleNotDef),
	femNotDef = median(model.frame(m4)$femNotDef),
	pct_fem = median(model.frame(m4)$pct_fem),
	liberal = median(model.frame(m4)$liberal),
	comp = median(model.frame(m4)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	runnerParty1997 = 1,
	runnerParty2002 = 0,
	runnerParty2007 = 0,
	runnerParty2012 = 0,
	runnerParty2017 = 0
	)
xValues02 <- cbind(
	intercept = 1,
	runnerParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m4)$femDef),	
	maleNotDef  = median(model.frame(m4)$maleNotDef),
	femNotDef = median(model.frame(m4)$femNotDef),
	pct_fem = median(model.frame(m4)$pct_fem),
	liberal = median(model.frame(m4)$liberal),
	comp = median(model.frame(m4)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	runnerParty1997 = 0,
	runnerParty2002 = 1,
	runnerParty2007 = 0,
	runnerParty2012 = 0,
	runnerParty2017 = 0
	)
xValues07 <- cbind(
	intercept = 1,
	runnerParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m4)$femDef),	
	maleNotDef  = median(model.frame(m4)$maleNotDef),
	femNotDef = median(model.frame(m4)$femNotDef),
	pct_fem = median(model.frame(m4)$pct_fem),
	liberal = median(model.frame(m4)$liberal),
	comp = median(model.frame(m4)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	runnerParty1997 = 0,
	runnerParty2002 = 0,
	runnerParty2007 = 1,
	runnerParty2012 = 0,
	runnerParty2017 = 0
	)
xValues12 <- cbind(
	intercept = 1,
	runnerParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m4)$femDef),	
	maleNotDef  = median(model.frame(m4)$maleNotDef),
	femNotDef = median(model.frame(m4)$femNotDef),
	pct_fem = median(model.frame(m4)$pct_fem),
	liberal = median(model.frame(m4)$liberal),
	comp = median(model.frame(m4)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	runnerParty1997 = 0,
	runnerParty2002 = 0,
	runnerParty2007 = 0,
	runnerParty2012 = 1,
	runnerParty2017 = 0
	)
xValues17 <- cbind(
	intercept = 1,
	runnerParty = 1,
	year1997 = 0, 
	year2002 = 0,
	year2007 = 0,
	year2012 = 0,
	year2017 = 0,
	femDef = median(model.frame(m4)$femDef),	
	maleNotDef  = median(model.frame(m4)$maleNotDef),
	femNotDef = median(model.frame(m4)$femNotDef),
	pct_fem = median(model.frame(m4)$pct_fem),
	liberal = median(model.frame(m4)$liberal),
	comp = median(model.frame(m4)$comp),
	left_not = 0, 
	left_in = 1, 
	center_left_not = 0,
	center_left_in = 1,
	center_not = 1, 
	center_in = 0, 
	center_right_not = 0,
	center_right_in = 0,
	right_not = 0, 
	right_in = 0, 	
	runnerParty1997 = 0,
	runnerParty2002 = 0,
	runnerParty2007 = 0,
	runnerParty2012 = 0,
	runnerParty2017 = 1
	)
# Calculate linear predictor
rBase <- sims %*% t(xValuesBase)
r93 <- sims %*% t(xValues93)
r97 <- sims %*% t(xValues97)
r02 <- sims %*% t(xValues02)
r07 <- sims %*% t(xValues07)
r12 <- sims %*% t(xValues12)
r17 <- sims %*% t(xValues17)

# Calculate Pr
pBase <- plogis(rBase)
p93 <- plogis(r93)
p97 <- plogis(r97)
p02 <- plogis(r02)
p07 <- plogis(r07)
p12 <- plogis(r12)
p17 <- plogis(r17)

# Get quantities
qBase <- quantile(pBase, probs = c(0.025, 0.5, 0.975))
q93 <- quantile(p93 - pBase, probs = c(0.025, 0.5, 0.975))
q97 <- quantile(p97 - pBase, probs = c(0.025, 0.5, 0.975))
q02 <- quantile(p02 - pBase, probs = c(0.025, 0.5, 0.975))
q07 <- quantile(p07 - pBase, probs = c(0.025, 0.5, 0.975))
q12 <- quantile(p12 - pBase, probs = c(0.025, 0.5, 0.975))
q17 <- quantile(p17 - pBase, probs = c(0.025, 0.5, 0.975))

pdf('~/runnerCoatTail.pdf', width = 10, height = 6)
par(mar = c(5, 8, 2, 2))
plot(y = c(q93[2], q97[2], q02[2], q07[2], q12[2], q17[2])
	, x = c(1993, 1997, 2002, 2007, 2012, 2017)
	, xlim = c(1992, 2018)
	, ylim = c(-0.1, 0.8)
	, type = 'p'
	, pch = 20
	, xlab = 'Election Year'
	, ylab = 'Difference Pr that a Women is Elected: \n Runner up Coattails - No Runner up Coattails'
	, cex.lab = 1.5
	, cex = 1.5
	, axes = FALSE)
axis(1, at = c(1993, 1997, 2002, 2007, 2012, 2017), tick = FALSE, cex.axis = 1.5)
axis(2, at = seq(-0.1, 0.8, 0.1), tick = TRUE, cex.axis = 1.1)
qs <- list(q93, q97, q02, q07, q12, q17)
years <- c(1993, 1997, 2002, 2007, 2012, 2017)
for(i in 1:6){
	lines(x = c(years[i], years[i]), y = c(qs[[i]][1], qs[[i]][3]))	
}
abline(h = 0, lty = 2)
dev.off()
