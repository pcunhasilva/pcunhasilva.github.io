rm(list = ls())

# Load Libraries
library(stargazer)
library(multiwayvcov)

# Load Data
load(file = '~/finalDataCandLevel.RData')

# Gen prezParty
fraPartyLevel$prezParty <- 0
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'La République En Marche!' & fraPartyLevel$year == 2017] <- 1
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'Socialist Party' & fraPartyLevel$year == 2012] <- 1
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'Rally for the Republic/Union for a Popular Movement/The Republicans' & fraPartyLevel$year == 2007] <- 1
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'Rally for the Republic/Union for a Popular Movement/The Republicans' & fraPartyLevel$year == 2002] <- 1
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'Rally for the Republic/Union for a Popular Movement/The Republicans' & fraPartyLevel$year == 1997] <- 1
fraPartyLevel$prezParty[fraPartyLevel$partyname== 'Socialist Party' & fraPartyLevel$year == 1993] <- 1

# Gen runnerup
fraPartyLevel$runnerup <- 0
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'National Front' & fraPartyLevel$year == 2017] <- 1
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'Rally for the Republic/Union for a Popular Movement/The Republicans' & fraPartyLevel$year == 2012] <- 1
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'Socialist Party' & fraPartyLevel$year == 2007] <- 1
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'National Front' & fraPartyLevel$year == 2002] <- 1
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'Socialist Party' & fraPartyLevel$year == 1997] <- 1
fraPartyLevel$runnerup[fraPartyLevel$partyname== 'Rally for the Republic/Union for a Popular Movement/The Republicans' & fraPartyLevel$year == 1993] <- 1

# Female and PrezParty
fraPartyLevel$prezPartyFem <- as.numeric(fraPartyLevel$prezParty == 1 & fraPartyLevel$fem == 1)

# Male and Prez party
fraPartyLevel$prezPartyMale <- as.numeric(fraPartyLevel$prezParty == 1 & fraPartyLevel$fem == 0)

# Male and Non-Prez party
fraPartyLevel$nonPrezPartyMale <- as.numeric(fraPartyLevel$prezParty == 0 & fraPartyLevel$fem == 0)

# Create Competitiveness
fraPartyLevel$comp <- (1 - fraPartyLevel$difVS) * 100

# Year Factor
fraPartyLevel$yearF <- as.factor(fraPartyLevel$year)

# Party Factor
fraPartyLevel$partyF <- as.factor(as.numeric(as.factor(fraPartyLevel$partyname)))

# Table F.8: Run Model (All Candidates)
m1 <- glm(winner ~ (prezParty) * yearF
	+ incDef
	+ fem
	+ dc
	, family = 'binomial'
	, data = fraPartyLevel)
summary(m1)
se1 = sqrt(diag(cluster.vcov(m1, fraPartyLevel$dc)))
stargazer::stargazer(m1
	, se = list(se1)
	, no.space = TRUE
	, single.row = TRUE
	, order = c(1, 618, 619, 620, 621, 622)
	, covariate.labels = c('Presidential Coattail'
		, 'Presidential Coattail X 1997'
		, 'Presidential Coattail X 2002'
		, 'Presidential Coattail X 2007'
		, 'Presidential Coattail X 2012'
		, 'Presidential Coattail X 2017'
		, '1997 Election'
		, '2002 Election'
		, '2007 Election'
		, '2012 Election'
		, '2017 Election'
		, 'Incumbent'
		, 'Woman')
	, omit = 'dc'
	, dep.var.labels = 'Candidate is Elected'
	, star.cutoffs = c(0.05, 0.01, 0.001)
	, title = c('Presidential Coattail and Candidate Election--France Legislative Elections, 1993-2017')
	, label = 'tab:prezCoatAll'
	)

# Table F.9: By Gender
m2 <- glm(winner ~ (prezPartyFem + prezPartyMale + nonPrezPartyMale) * yearF
	+ incDef
	+ dc
	, family = 'binomial'
	, data = fraPartyLevel)
summary(m2)
se2 = sqrt(diag(cluster.vcov(m2, fraPartyLevel$dc)))
stargazer::stargazer(m2
	, se = list(se2)
	, no.space = TRUE
	, single.row = TRUE
	, order = c(1, 618, 619, 620, 621, 622, 623
		, 2, 624:628, 3, 629:633
		)
	, covariate.labels = c('Presidential Coattail (Female)'
		, 'Presidential Coattail (Female) X 1997'
		, 'Presidential Coattail (Female) X 2002'
		, 'Presidential Coattail (Female) X 2007'
		, 'Presidential Coattail (Female) X 2012'
		, 'Presidential Coattail (Female) X 2017'
	  	, 'Presidential Coattail (Male)'
		, 'Presidential Coattail (Male) X 1997'
		, 'Presidential Coattail (Male) X 2002'
		, 'Presidential Coattail (Male) X 2007'
		, 'Presidential Coattail (Male) X 2012'
		, 'Presidential Coattail (Male) X 2017'	
	  	, 'Non-Presidential Party (Male)'
		, 'Non-Presidential Party (Male) X 1997'
		, 'Non-Presidential Party (Male) X 2002'
		, 'Non-Presidential Party (Male) X 2007'
		, 'Non-Presidential Party (Male) X 2012'
		, 'Non-Presidential Party (Male) X 2017'		
		, '1997 Election'
		, '2002 Election'
		, '2007 Election'
		, '2012 Election'
		, '2017 Election'
		, 'Incumbent')
	, add = list(c('District FE', 'Yes'))
	, omit = 'dc'
	, dep.var.labels = 'Candidate is Elected'
	, star.cutoffs = c(0.05, 0.01, 0.001)
	, title = c("Presidential Coattail given the Candidate's Gender and Candidate Election--France Legislative Elections, 1993-2017")
	, label = 'tab:prezCoatSplit'
	)