library(gsynth)

rm(list = ls())

# Load Data
load(file = '~/gsFinal.RData')

# Add dual mandate (Coded using Navarro 2013, Wikipedia)
finalGSData$dual <- 0
finalGSData$dual[finalGSData$iso3 == 'FRA' & finalGSData$year < 2017] <- 1
finalGSData$dual[finalGSData$iso3 == 'FIN'] <- 1
finalGSData$dual[finalGSData$iso3 == 'DEU'] <- 1
finalGSData$dual[finalGSData$iso3 == 'AUT'] <- 1
finalGSData$dual[finalGSData$iso3 == 'DNK'] <- 1
finalGSData$dual[finalGSData$iso3 == 'NLD'] <- 1
finalGSData$dual[finalGSData$iso3 == 'SWE'] <- 1
# We don't add this variable to the models because of collinearity

###### Table 1: Model 2
set.seed(123)
out.par <- gsynth(fem_pct ~ treated + lngdp + laborfem + pquotas  + clpr
	, data = finalGSData
	, index = c("iso3", "year")
	, force = "two-way"
	, min.T0 = 5
	, CV = TRUE
	, se = TRUE
	, k = 5
	, estimator = 'ife'
	, inference = 'parametric'
	, nboots = 2000
	, seed = 123
	, parallel = FALSE)
out.par

# Factor Plots - Figure C2
pdf('~/factorLoadingsM2.pdf', width = 6, height = 6)
par(mar = c(5, 5, 2, 2))
plot(density(out.par$lambda.co[,1]), main = ''
	, xlab = 'Estimated Factor Loading'
	, ylab = 'Density'
	, cex.lab = 2
	, axes = FALSE)
axis(1, cex.axis = 1.25)
axis(2, cex.axis = 1.25)
abline(v = out.par$lambda.tr[, 1], lwd = 2)
plot(density(out.par$lambda.co[,2])
	, main = ''
	, xlab = 'Estimated Factor Loading'
	, ylab = 'Density'
	, cex.lab = 2
	, axes = FALSE)
axis(1, cex.axis = 1.25)
axis(2, cex.axis = 1.25)	
abline(v = out.par$lambda.tr[, 2], lwd = 2)
dev.off()

###### Table 1: Model 1
set.seed(123)
out.par.nocontrols <- gsynth(fem_pct ~ treated
	, data = finalGSData
	, index = c("iso3", "year")
	, force = "two-way"
	, min.T0 = 5
	, CV = TRUE
	, se = TRUE
	, k = 5
	, estimator = 'ife'
	, inference = 'parametric'
	, nboots = 2000
	, seed = 123
	, parallel = FALSE)
out.par.nocontrols

# Factor Plots - Figure C1
pdf('~/factorLoadingsM1.pdf', width = 6, height = 6)
par(mar = c(5, 5, 2, 2))
plot(density(out.par.nocontrols$lambda.co[,1]), main = ''
	, xlab = 'Estimated Factor Loading'
	, ylab = 'Density'
	, cex.lab = 2
	, axes = FALSE)
axis(1, cex.axis = 1.25)
axis(2, cex.axis = 1.25)
abline(v = out.par.nocontrols$lambda.tr[, 1], lwd = 2)
plot(density(out.par.nocontrols$lambda.co[,2])
	, main = ''
	, xlab = 'Estimated Factor Loading'
	, ylab = 'Density'
	, cex.lab = 2
	, axes = FALSE)
axis(1, cex.axis = 1.25)
axis(2, cex.axis = 1.25)	
abline(v = out.par.nocontrols$lambda.tr[, 2], lwd = 2)
plot(density(out.par.nocontrols$lambda.co[,3])
	, main = ''
	, xlab = 'Estimated Factor Loading'
	, ylab = 'Density'
	, cex.lab = 2
	, axes = FALSE)
axis(1, cex.axis = 1.25)
axis(2, cex.axis = 1.25)	
abline(v = out.par.nocontrols$lambda.tr[, 3], lwd = 2)
dev.off()


# Figure 1: Real X Synt France
pdf('~/realSynth.pdf', width = 10, height = 6)
par(mar = c(5, 7, 2, 2))
plot(y = out.par$Y.tr, x = unique(finalGSData$year), 
	type = 'l', lwd = 3, ylim = c(0, 50),
	xlab = '', ylab = 'Percentage of Female Legislators',
	axes = FALSE, cex.lab = 2)	
lines(x = unique(finalGSData$year), y = out.par$Y.ct, type = 'l', lwd = 1.5, col = 'grey')
axis(1, at = unique(finalGSData$year), las = 2, cex.axis = 1.5)
axis(2, cex.axis = 1.5, las = 2)
legend('bottomright', legend = c('Real France', 'Synthetic France'),
	lty = c(1, 1), col = c('black', 'grey'), lwd = c(3, 1.5),
	bty = 'n')
abline(v = 2002, lty = 2)
dev.off()


# Figure 2
pdf('~/gscEffect.pdf', width = 10, height = 6)
par(mar = c(5, 7, 2, 2))
plot(x = out.par$time, y = out.par$est.att[, 'ATT'],
	axes = FALSE, ylab = 'Estimated Effect of Quotas', xlab = '',
	ylim = c(-10, 32), xlim = c(1988, 2019), type = 'n', cex.lab = 2)
polygon(x = c(out.par$time , rev(out.par$time)), 
	y = c(out.par$est.att[, 'CI.upper'], rev(out.par$est.att[, 'CI.lower'])),
     col = "grey90", border = NA)
lines(x = out.par$time, y = out.par$est.att[, 'ATT'], type = 'l', col = 'black', lwd = 3)
# lines(x = out.par$time, y = out.par$est.att[, 'CI.lower'], lty = 2)
# lines(x = out.par$time, y = out.par$est.att[, 'CI.upper'], lty = 2)
axis(1, at = unique(out.par$time), las = 2, cex.axis = 1.5)
axis(2, cex.axis = 1.5, las = 2)
abline(h = 0, lty = 2, lwd = 0.8)
abline(v = 2002, lty = 1, lwd = 0.8)
dev.off()

####### Appendix H:
###### H.1: Non-presidential countries and no quotas
set.seed(123)
out.rob1 <- gsynth(fem_pct ~ treated + lngdp + laborfem + pquotas  + clpr
	, data = finalGSData[finalGSData$iso3 != 'USA', ]
	, index = c("iso3", "year")
	, force = "two-way"
	, min.T0 = 5
	, CV = TRUE
	, se = TRUE
	, k = 5
	, estimator = 'ife'
	, inference = 'parametric'
	, nboots = 2000
	, seed = 123
	, parallel = FALSE)
out.rob1


###### H.2:Non-presidential countries with and without quota
load(file = '/gsNonPrezFinal.RData')
set.seed(123)
out.rob2 <- gsynth(fem_pct ~ treated + lngdp + laborfem + pquotas  + clpr + qt_imp
	, data = finalGSData2
	, index = c("iso3", "year")
	, force = "two-way"
	, min.T0 = 5
	, CV = TRUE
	, se = TRUE
	, k = 5
	, estimator = 'ife'
	, inference = 'parametric'
	, nboots = 2000
	, seed = 123
	, parallel = FALSE)
out.rob2
