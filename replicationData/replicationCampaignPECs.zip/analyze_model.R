# Prepare Tables and Plots for the main hypothesis in 
# Campaign Resources and Pre-Electoral Coalitions
# Author: Patrick Cunha Silva

setwd('ReplicationFiles')

# Libraries
library(stargazer)
library(readstata13)
library(mvtnorm)
library(miscTools)

rm(list = ls())

# Load File
join <- read.dta13('RE_Join.dta')
lead <- read.dta13('RE_Lead.dta')
solo <- read.dta13('RE_Solo.dta')

# Load data
data_join <- read.dta13('dataRE_Join.dta')
data_lead <- read.dta13('dataRE_Lead.dta')
data_solo <- read.dta13('dataRE_Solo.dta')

# Combine data
modeldata <- rbind(data_join, data_lead, data_solo)

# Keep unique observations (it should be equal to 299442)
modeldata <- modeldata[!duplicated(modeldata),]
nrow(modeldata)

# Variables used
vars <- c('fbt', 'voteshare_t1', 'voteshare_x_fbt'
	, 'runoff', 'enpp', 'compt'
	, 'incumbent', 'runPrevious'
	, 'lngdpcap', 'lnpoplag', 'poprural'
	, 'year12', 'year16'
	, paste0('partido', 2:35))

# Get Betas (beta49 is the lnsig2u)
betas_join <- paste0('beta', 1:48)
betas_lead <- paste0('beta', 1:48)
betas_solo <- paste0('beta', 1:48)
betas_join <- as.matrix(join[1, betas_join])
betas_lead <- as.matrix(lead[1, betas_lead])
betas_solo <- as.matrix(solo[1, betas_solo])

# Get VCOV
vcov <- matrix(0, ncol = 48 * 3, nrow = 48 * 3)
vcov_join <- paste0('vcov', 1:48)
vcov_lead <- paste0('vcov', 1:48)
vcov_solo <- paste0('vcov', 1:48)
vcov_join <- as.matrix(join[, vcov_join])
vcov_join <- vcov_join[-49, ]
vcov_lead <- as.matrix(lead[, vcov_lead])
vcov_lead <- vcov_lead[-49, ]
vcov_solo <- as.matrix(solo[, vcov_solo])
vcov_solo <- vcov_solo[-49, ]

# Simulate Betas
set.seed(1223)
joinSim <- rmvnorm(n = 1000, mean = betas_join, sigma = vcov_join)
set.seed(1223)
leadSim <- rmvnorm(n = 1000, mean = betas_lead, sigma = vcov_lead)
set.seed(1223)
soloSim <- rmvnorm(n = 1000, mean = betas_solo, sigma = vcov_solo)

# Scenarioss
xValues0 <- as.matrix(colMedians(modeldata[, vars]))
xValues0['fbt',] <- 0
xValues0['voteshare_x_fbt',] <- 0
xValues0 <- rbind(xValues0, 1)
xValues1 <- as.matrix(colMedians(modeldata[, vars]))
xValues1['fbt', ] <- 1
xValues1 <- rbind(xValues1, 1)
# Values for Z
votes <- seq(0, 1, by = 0.001)

# Function to Calculate probabilities
probsSim <- function(votes, fbt = 0, sims = list(joinSim, leadSim, soloSim), xValues0 = xValues0, xValues1 = xValues1){
	# Does not consider the coefficients for the FEs
	if(fbt == 0){
			linearPred02 <- sims[[1]] %*% xValues0
			linearPred03 <- sims[[2]] %*% xValues0
			linearPred04 <- sims[[3]] %*% xValues0
			probsim02 <- exp(linearPred02)/(1 + exp(linearPred02) + exp(linearPred03) + exp(linearPred04))
			probsim03 <- exp(linearPred03)/(1 + exp(linearPred02) + exp(linearPred03) + exp(linearPred04))
			probsim04 <- exp(linearPred04)/(1 + exp(linearPred02) + exp(linearPred03) + exp(linearPred04))
			probsim01 <- 1 - (probsim02 + probsim03 + probsim04)
			probsimAll0 <- cbind(probsim01, probsim02, probsim03, probsim04)
			return(probsimAll0)
		}
	# fbt = 1
	xValues1['voteshare_x_fbt', 1] <- votes
	linearPred12 <- sims[[1]] %*% xValues1
	linearPred13 <- sims[[2]] %*% xValues1
	linearPred14 <- sims[[3]] %*% xValues1
	probsim12 <- exp(linearPred12)/(1 + exp(linearPred12) + exp(linearPred13) + exp(linearPred14))
	probsim13 <- exp(linearPred13)/(1 + exp(linearPred12) + exp(linearPred13) + exp(linearPred14))
	probsim14 <- exp(linearPred14)/(1 + exp(linearPred12) + exp(linearPred13) + exp(linearPred14))
	probsim11 <- 1 - (probsim12 + probsim13 + probsim14)
	probsimAll1 <- cbind(probsim11, probsim12, probsim13, probsim14)
	# Return probs
	return(probsimAll1)
}
# Calculate Probs
probs0 <- sapply(votes, probsSim, fbt = 0, xValues0 = xValues0, simplify = FALSE)
probs1 <- sapply(votes, probsSim, fbt = 1, xValues1 = xValues1, simplify = FALSE)

# Calculate Probls
notrun_p <- sapply(1:1001, function(i) quantile(probs1[[i]][, 1] - probs0[[i]][, 1], probs = c(0.025, 0.05, 0.5, 0.95, 0.975)), simplify = FALSE)
notrun_p <- Reduce('rbind', notrun_p)
support_p <- sapply(1:1001, function(i) quantile(probs1[[i]][, 2] - probs0[[i]][, 2], probs = c(0.025, 0.05, 0.5, 0.95, 0.975)), simplify = FALSE)
support_p <- Reduce('rbind', support_p)
lead_p <- sapply(1:1001, function(i) quantile(probs1[[i]][, 3] - probs0[[i]][, 3], probs = c(0.025, 0.05, 0.5, 0.95, 0.975)), simplify = FALSE)
lead_p <- Reduce('rbind', lead_p)
solo_p <- sapply(1:1001, function(i) quantile(probs1[[i]][, 4] - probs0[[i]][, 4], probs = c(0.025, 0.05, 0.5, 0.95, 0.975)), simplify = FALSE)
solo_p <- Reduce('rbind', solo_p)	

# Put everything in a list
probs <- list(notrun_p, support_p, lead_p, solo_p)

#################################################
#------------- Plot the results ----------------#
#################################################

# Function to generate the plots
genPlot <- function(Probs, cat = 1, ylabtext, ylim = c(-0.1, 0.1), modeldata){

	par(mar = c(4, 7, 4, 4))
	plot(y = Probs[[cat]][, '50%']
		, x = seq(0, 1, 0.001)
		, ylim = ylim
		, pch = 19
		, axes = FALSE
		, ylab = ylabtext
		, xlab = 'Vote Share'
		, cex.lab = 2
		, type = 'l'
		, cex = 0.5
		)
	votes <- seq(0, 1, 0.001)
	lines(y = c(Probs[[cat]][, '2.5%']), x = c(votes), lty = 3)
	lines(y = c(Probs[[cat]][, '97.5%']), x = c(votes), lty = 3)
	abline(h = 0, lwd = 0.5, lty = 2)
	axis(1, cex.axis = 2)
	axis(2, cex.axis = 2)
	par(new = TRUE)
	rug(modeldata[, 'voteshare_t1'])
}

# Difference in Probabilities 
genPlot(Probs = probs, cat = 2
	, ylim = c(-0.15, 0.05)
	, ylabtext = 'Difference in Probability of Joining a PEC'
	, modeldata = modeldata)

genPlot(Probs = probs, cat = 1
	, ylim = c(-0.2, 0.05)
	, ylabtext = 'Difference in Probability of Not Entering'
	, modeldata = modeldata)

genPlot(Probs = probs, cat = 3
	, ylim = c(-0.10, 0.4)
	, ylabtext = 'Difference in Probability of Leading a PEC'
	, modeldata = modeldata)

genPlot(Probs = probs, cat = 4
	, ylim = c(-0.02, 0.01)
	, ylabtext = 'Difference in Probability of Running Solo'
	, modeldata = modeldata)
dev.off()


#----------- Full Table ----------#

# Put everything in a table
toTable <- matrix(NA, ncol = 3, nrow = 24)
# Add Betas
toTable[seq(1, 24, by = 2), 1] <- round(betas_join[c(1:11, 48)], 3)
toTable[seq(1, 24, by = 2), 2] <- round(betas_lead[c(1:11, 48)], 3)
toTable[seq(1, 24, by = 2), 3] <- round(betas_solo[c(1:11, 48)], 3)
# Add Confidence Intervals
lb_join <- betas_join[c(1:11, 48)] + sqrt(diag(vcov_join))[c(1:11, 48)] * qnorm(0.025)
ub_join <- betas_join[c(1:11, 48)] + sqrt(diag(vcov_join))[c(1:11, 48)] * qnorm(0.975)
lb_lead <- betas_lead[c(1:11, 48)] + sqrt(diag(vcov_lead))[c(1:11, 48)] * qnorm(0.025)
ub_lead <- betas_lead[c(1:11, 48)] + sqrt(diag(vcov_lead))[c(1:11, 48)] * qnorm(0.975)
lb_solo <- betas_solo[c(1:11, 48)] + sqrt(diag(vcov_solo))[c(1:11, 48)] * qnorm(0.025)
ub_solo <- betas_solo[c(1:11, 48)] + sqrt(diag(vcov_solo))[c(1:11, 48)] * qnorm(0.975)
toTable[seq(2, 24, by = 2), 1] <- paste0('(', round(lb_join, 3), ', ', round(ub_join, 3), ')')
toTable[seq(2, 24, by = 2), 2] <- paste0('(', round(lb_lead, 3), ', ', round(ub_lead, 3), ')')
toTable[seq(2, 24, by = 2), 3] <- paste0('(', round(lb_solo, 3), ', ', round(ub_solo, 3), ')')

# Sigma
toTable <- rbind(toTable, round(c(join$sigma1[1], lead$sigma1[1], solo$sigma1[1]), 3))

# Add N of Groups
toTable <- rbind(toTable, c(length(unique(modeldata$codeF))))

# Add N of Observations
toTable <- rbind(toTable, nrow(modeldata))

# Add Names
rownames(toTable) <- c('FBT', ''
	, 'Vote Share', ''
	, 'Vote Share times FBT', ''
	, 'Run-off', ''
	, 'ENPv', ''
	, 'Lack of Competitiveness', ''
	, 'Incumbent' , ''
	, 'Run Previously', ''
	, 'GDP per capita (log)', ''
	, 'Population (log)', ''	
	, 'Rural Population (%)', ''
	, 'Intercept', ''
	, 'sigma'
	, 'N Groups'
	, 'N')
stargazer::stargazer(toTable)
