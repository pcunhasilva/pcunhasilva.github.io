
# The original version of this code was written using: 
# rdrobust version: 0.99.1
# rddensity version: 1.0
# To replicate this code exactly as they are in the paper, 
# you need to use these two lines
library(devtools)
install_version('rdrobust', version = "0.99.1")
install_version('rddensity', version = "1.0")

library(readxl)
library(plyr)
library(dplyr)
library(rdrobust)
library(rddensity)
library(lfe)
library(DataCombine)


rm(list = ls())
# Set WD
setwd("~/Replication Files")

#-------------- Load Data -------------#
load(file = 'france01Final.RData')
load(file = 'france08Final.RData')
load(file = 'france14Final.RData')
load(file = 'france20Final.RData')
france <- rbind.fill(franceData20, franceData14, franceData08, franceData01)

######################################
### Check Density at the Threshold ###
######################################
summary(t1 <- rddensity(X = franceData01$zpop, c = 0)) # No sorting
summary(t2 <- rddensity(X = franceData08$zpop, c = 0)) # No sorting
summary(t3 <- rddensity(X = franceData14$zpop, c = 0)) # No sorting
summary(t4 <- rddensity(X = franceData20$zpop, c = 0)) # No sorting
pdf('densityPlots.pdf')
# Density Plot 2001
hist(franceData01$zpop[abs(franceData01$zpop)<=0.116], breaks = 80, # the estimated BW
	main = "", xlab = "Municipal Population (Re-centered at the Threshold = 3,500)")
abline(v = 0, col = "red", lwd = 1.5)
text(x = 0.07, y = 50, 
	labels = paste("p-value density test = ", 
		round(t1$test$p_jk,2)), cex = 1)
# Density Plot 2008
hist(franceData08$zpop[abs(franceData08$zpop)<=0.125], breaks = 80, # the estimated BW
	main = "", xlab = "Municipal Population (Re-centered at the Threshold = 1,000)")
abline(v = 0, col = "red", lwd = 1.5)
text(x = 0.07, y = 80, 
	labels = paste("p-value density test = ", 
		round(t2$test$p_jk,2)), cex = 1)
# Density Plot 2014
hist(franceData14$zpop[abs(franceData14$zpop)<=0.062], breaks = 80, # the estimated BW
	main = "", xlab = "Municipal Population (Re-centered at the Threshold = 1,000)")
abline(v = 0, col = "red", lwd = 1.5)
text(x = 0.04, y = 300, 
	labels = paste("p-value density test = ", 
		round(t3$test$p_jk,2)), cex = 1)
# Density Plot 2020
hist(franceData20$zpop[abs(franceData20$zpop)<=0.045], breaks = 80, # the estimated BW
	main = "", xlab = "Municipal Population (Re-centered at the Threshold = 1,000)")
abline(v = 0, col = "red", lwd = 1.5)
text(x = 0.03, y = 150, 
	labels = paste("p-value density test = ", 
		round(t4$test$p_jk,2)), cex = 1)
dev.off()

######################
### RDD - Figure 1 ###
######################
out01 <- rdrobust(y = franceData01$pctinvalid
		, x = franceData01$zpop
		, p = 1
		, c = 0
		, level = 99
		, all = TRUE)
out08 <- rdrobust(y = franceData08$pctinvalid
		, x = franceData08$zpop
		, p = 1
		, c = 0
		, level = 99
		, all = TRUE)
out14 <- rdrobust(y = franceData14$pctinvalid
		, x = franceData14$zpop
		, p = 1
		, c = 0
		, level = 99		
		, all = TRUE)
out20 <- rdrobust(y = franceData20$pctinvalid
		, x = franceData20$zpop
		, p = 1
		, c = 0
		, level = 99	
		, all = TRUE)
summary(out01)
summary(out08)
summary(out14)
summary(out20)


pdf('RDDPlot.pdf')
rdplot(y = franceData01$pctinvalid
	, x = franceData01$zpop
	, c = 0
	, h = out01$bws['b', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.20, 0.20)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Percentage of Invalid Votes')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 3,500)"))
abline(v = 0, col = 'red')
text(x = -0.1, y = 18, 
	labels = paste0("RD Effect = ", round(out01$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.1, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out01$ci['Robust', 1], 3), ', ', round(out01$ci['Robust', 2], 3), ']'))
		, cex = 1)

rdplot(y = franceData08$pctinvalid
	, x = franceData08$zpop
	, c = 0
	, h = out08$bws['b', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.17, 0.17)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Percentage of Invalid Votes')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 3,500)"))
abline(v = 0, col = 'red')
text(x = -0.075, y = 18, 
	labels = paste0("RD Effect = ", round(out08$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.075, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out08$ci['Robust', 1], 3), ', ', round(out08$ci['Robust', 2], 3), ']'))
		, cex = 1)

rdplot(y = franceData14$pctinvalid
	, x = franceData14$zpop
	, c = 0
	, h = out14$bws['b', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.10, 0.10)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Percentage of Invalid Votes')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 1,000)"))
abline(v = 0, col = 'red')
text(x = -0.05, y = 18, 
	labels = paste0("RD Effect = ", round(out14$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.05, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out14$ci['Robust', 1], 3), ', ', round(out14$ci['Robust', 2], 3), ']'))
		, cex = 1)

rdplot(y = franceData20$pctinvalid
	, x = franceData20$zpop
	, c = 0
	, h = out20$bws['b', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.07, 0.07)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Percentage of Invalid Votes')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 1,000)"))
abline(v = 0, col = 'red')
text(x = -0.03, y = 18, 
	labels = paste0("RD Effect = ", round(out20$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.03, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out20$ci['Robust', 1], 3), ', ', round(out20$ci['Robust', 2], 3), ']'))
		, cex = 1)
dev.off()

# Table
betas <- c(out01$Estimate[1, 'tau.bc'], out08$Estimate[1, 'tau.bc'], out14$Estimate[1, 'tau.bc'], out20$Estimate[1, 'tau.bc'])
SEs <- c(out01$Estimate[1, 'se.rb'], out08$Estimate[1, 'se.rb'], out14$Estimate[1, 'se.rb'], out20$Estimate[1, 'se.rb'])
h <- c(out01$bws['h', 'left'], out08$bws['h', 'left'], out14$bws['h', 'left'], out20$bws['h', 'left'])
nCo <- c(out01$N_h_l[1], out08$N_h_l[1], out14$N_h_l[1], out20$N_h_l[1])
nTr <- c(out01$N_h_r[1], out08$N_h_r[1], out14$N_h_r[1], out20$N_h_r[1])
ci <- rbind(out01$ci['Robust', ], out08$ci['Robust', ], out14$ci['Robust', ], out20$ci['Robust', ])
pv <- c(out01$pv['Robust', ], out08$pv['Robust', ], out14$pv['Robust', ], out20$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 4)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']')
	, paste0('[', round(ci[3, 1], 3), ', ', round(ci[3, 2], 3), ']')
	, paste0('[', round(ci[4, 1], 3), ', ', round(ci[4, 2], 3), ']'))
myTable[, 3] <-  round(pv, 3)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c(2001, 2008, 2014, 2020)
stargazer::stargazer(myTable, summary = FALSE)

###################################
# Placebo 2014 and 2020 (Table 1) #
###################################
franceData14$zTemp <- scale(franceData14$lagPop, center = 3500)
out14Placebo <- rdrobust(y = franceData14$pctinvalid
		, x = franceData14$zTemp
		, level = 99
		, p = 1
		, c = 0
		, all = TRUE)
summary(out14Placebo)
franceData20$zTemp <- scale(franceData20$lagPop, center = 3500)
out20Placebo <- rdrobust(y = franceData20$pctinvalid
		, x = franceData20$zTemp
		, level = 99
		, p = 1
		, c = 0
		, all = TRUE)
summary(out20Placebo)

pdf('RDDPlotPlacebo1420.pdf')
rdplot(y = franceData14$pctinvalid
	, x = franceData14$zTemp
	, c = 0
	, h = out14Placebo$bws['h', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.11, 0.11)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Invalid Votes')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 3,500)"))
abline(v = 0, col = 'red')
text(x = -0.05, y = 18, 
	labels = paste0("RD Effect = ", round(out14Placebo$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.05, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out14Placebo$ci['Robust', 1], 3), ', ', round(out14Placebo$ci['Robust', 2], 3), ']'))
		, cex = 1)

rdplot(y = franceData20$pctinvalid
	, x = franceData20$zTemp
	, c = 0
	, h = out20Placebo$bws['h', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.06, 0.06)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Invalid Votes')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 3,500)"))
abline(v = 0, col = 'red')
text(x = -0.03, y = 18, 
	labels = paste0("RD Effect = ", round(out20Placebo$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.03, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out20Placebo$ci['Robust', 1], 3), ', ', round(out20Placebo$ci['Robust', 2], 3), ']'))
		, cex = 1)
dev.off()

################################
### Lag DV (Table 1 Panel b) ###
################################
france$dc <- paste0(france$codedepart, '-', france$codecommune)
france <- france[order(france$dc, france$year),]
france <- DataCombine::slide(france, Var = 'pctinvalid'
	, NewVar = 'pctinvalidLag', TimeVar = 'year'
	, GroupVar = 'dc')
france <- DataCombine::slide(france, Var = 'pctinvalid'
	, NewVar = 'pctinvalidLag2', TimeVar = 'year',
	, GroupVar = 'dc', slideBy = -2)

out14Lag <- rdrobust(y = france$pctinvalidLag[france$year == 2014]
		, x = france$zpop[france$year == 2014]
		, level = 99
		, p = 1
		, c = 0
		, all = TRUE)
summary(out14Lag)
out20Lag <- rdrobust(y = france$pctinvalidLag2[france$year == 2020]
		, x = france$zpop[france$year == 2020]
		, level = 99
		, p = 1
		, c = 0		
		, all = TRUE)
summary(out20Lag)

pdf('RDDPlaceboLag1420.pdf')
rdplot(y = france$pctinvalidLag[france$year == 2014]
	, x = france$zpop[france$year == 2014]
	, c = 0
	, h = out14Lag$bws['h', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.04, 0.04)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Percentage of Invalid Votes in 2008')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 1,000)"))
abline(v = 0, col = 'red')
text(x = -0.02, y = 18, 
	labels = paste0("RD Effect = ", round(out14Lag$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.02, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out14Lag$ci['Robust', 1], 3), ', ', round(out14Lag$ci['Robust', 2], 3), ']'))
		, cex = 1)
rdplot(y = france$pctinvalidLag2[france$year == 2020]
	, x = france$zpop[france$year == 2020]
	, c = 0
	, h = out20Lag$bws['h', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.04, 0.04)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Percentage of Invalid Votes in 2008')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 1,000)"))
abline(v = 0, col = 'red')
text(x = -0.02, y = 18, 
	labels = paste0("RD Effect = ", round(out20Lag$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.02, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out20Lag$ci['Robust', 1], 3), ', ', round(out20Lag$ci['Robust', 2], 3), ']'))
		, cex = 1)
dev.off()

# Table
betas <- c(out14Placebo$Estimate[1, 'tau.bc'], out20Placebo$Estimate[1, 'tau.bc'], out14Lag$Estimate[1, 'tau.bc'], out20Lag$Estimate[1, 'tau.bc'])
SEs <- c(out14Placebo$Estimate[1, 'se.rb'], out20Placebo$Estimate[1, 'se.rb'], out14Lag$Estimate[1, 'se.rb'], out20Lag$Estimate[1, 'se.rb'])
h <- c(out14Placebo$bws['h', 'left'], out20Placebo$bws['h', 'left'], out14Lag$bws['h', 'left'], out20Lag$bws['h', 'left'])
nCo <- c(out14Placebo$N_h_l[1], out20Placebo$N_h_l[1], out14Lag$N_h_l[1], out20Lag$N_h_l[1])
nTr <- c(out14Placebo$N_h_r[1], out20Placebo$N_h_r[1], out14Lag$N_h_r[1], out20Lag$N_h_r[1])
ci <- rbind(out14Placebo$ci['Robust', ], out20Placebo$ci['Robust', ], out14Lag$ci['Robust', ], out20Lag$ci['Robust', ])
pv <- c(out14Placebo$pv['Robust', ], out20Placebo$pv['Robust', ], out14Lag$pv['Robust', ], out20Lag$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 4)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']')
	, paste0('[', round(ci[3, 1], 3), ', ', round(ci[3, 2], 3), ']')
	, paste0('[', round(ci[4, 1], 3), ', ', round(ci[4, 2], 3), ']'))
myTable[, 3] <-  round(pv, 3)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c(2001, 2008, 2014, 2020)
stargazer::stargazer(myTable, summary = FALSE)



########################
# Different Bandwidhts #
########################

plotBand <- function(mydata = franceData01, ci = 99, paperFit = out01){
	bands <- seq(0.01, 0.3, 0.01)
	betas <- as.numeric()
	CIplot <- matrix(NA, ncol = 2, nrow = length(bands))
	for(i in 1:length(bands)){
		out <- rdrobust(y = mydata$pctinvalid
			, x = mydata$zpop
			, h = bands[i]
			, p = 1
			, c = 0
			, level = ci
			, all = TRUE)	
		betas[i] <- out$Estimate[1, 'tau.bc']
		CIplot[i,] <- out$ci['Robust', ]
	}
	par(mar = c(6, 6, 2, 2))
	plot(x = bands
		, y = betas
		, type = 'l'
		, ylim = c(round(min(CIplot)), round(max(CIplot)))
		, ylab = 'Estimated Effect'
		, xlab = 'Bandwidth'
		, axes = FALSE
		, cex.lab = 2)
	lines(x = bands, y = CIplot[, 1], lty = 2)
	lines(x = bands, y = CIplot[, 2], lty = 2)
	abline(h = 0, lty = 3)
	abline(v = paperFit$bws['h', 'left'], col = 'red')
	axis(1, cex.axis = 1.5)
	axis(2, cex.axis = 1.5)
	}
pdf('Sensitivity.pdf')
plotBand(mydata = franceData01, paperFit = out01)
plotBand(mydata = franceData08, paperFit = out08)
plotBand(mydata = franceData14, paperFit = out14)
plotBand(mydata = franceData20, paperFit = out20)
dev.off()

#############################
####### P = {2, 3, 4} ####### 
#############################
out01p2 <- rdrobust(y = franceData01$pctinvalid
		, x = franceData01$zpop
		, p = 2
		, c = 0
		, level = 99		
		, all = TRUE)
out08p2 <- rdrobust(y = franceData08$pctinvalid
		, x = franceData08$zpop
		, p = 2
		, c = 0
		, level = 99
		, all = TRUE)
out14p2 <- rdrobust(y = franceData14$pctinvalid
		, x = franceData14$zpop
		, p = 2
		, c = 0
		, level = 99		
		, all = TRUE)
out20p2 <- rdrobust(y = franceData20$pctinvalid
		, x = franceData20$zpop,
		, p = 2
		, c = 0
		, level = 99			
		, all = TRUE)
summary(out01p2)
summary(out08p2)
summary(out14p2)
summary(out20p2)

out01p3 <- rdrobust(y = franceData01$pctinvalid
		, x = franceData01$zpop
		, p = 3
		, c = 0
		, level = 99	
		, all = TRUE)
out08p3 <- rdrobust(y = franceData08$pctinvalid
		, x = franceData08$zpop
		, p = 3
		, c = 0
		, level = 99	
		, all = TRUE)
out14p3 <- rdrobust(y = franceData14$pctinvalid
		, x = franceData14$zpop
		, p = 3
		, c = 0
		, level = 99				
		, all = TRUE)
out20p3 <- rdrobust(y = franceData20$pctinvalid
		, x = franceData20$zpop,
		, p = 3
		, c = 0
		, level = 99				
		, all = TRUE)
summary(out01p3)
summary(out08p3)
summary(out14p3)
summary(out20p3)

out01p4 <- rdrobust(y = franceData01$pctinvalid
		, x = franceData01$zpop
		, p = 4
		, c = 0
		, level = 99
		, all = TRUE)
out08p4 <- rdrobust(y = franceData08$pctinvalid
		, x = franceData08$zpop
		, p = 4
		, c = 0
		, level = 99		
		, all = TRUE)
out14p4 <- rdrobust(y = franceData14$pctinvalid
		, x = franceData14$zpop
		, p = 4
		, c = 0
		, level = 99				
		, all = TRUE)
out20p4 <- rdrobust(y = franceData20$pctinvalid
		, x = franceData20$zpop,
		, p = 4
		, c = 0
		, level = 99			
		, all = TRUE)
summary(out01p4)
summary(out08p4)
summary(out14p4)
summary(out20p4)


# Table
betas <- c(out01p2$Estimate[1, 'tau.bc'], out08p2$Estimate[1, 'tau.bc'], out14p2$Estimate[1, 'tau.bc'], out20p2$Estimate[1, 'tau.bc'])
SEs <- c(out01p2$Estimate[1, 'se.rb'], out08p2$Estimate[1, 'se.rb'], out14p2$Estimate[1, 'se.rb'], out20p2$Estimate[1, 'se.rb'])
h <- c(out01p2$bws['h', 'left'], out08p2$bws['h', 'left'], out14p2$bws['h', 'left'], out20p2$bws['h', 'left'])
nCo <- c(out01p2$N_h_l[1], out08p2$N_h_l[1], out14p2$N_h_l[1], out20p2$N_h_l[1])
nTr <- c(out01p2$N_h_r[1], out08p2$N_h_r[1], out14p2$N_h_r[1], out20p2$N_h_r[1])
ci <- rbind(out01p2$ci['Robust', ], out08p2$ci['Robust', ], out14p2$ci['Robust', ], out20p2$ci['Robust', ])
pv <- c(out01p2$pv['Robust', ], out08p2$pv['Robust', ], out14p2$pv['Robust', ], out20p2$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 4)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']')
	, paste0('[', round(ci[3, 1], 3), ', ', round(ci[3, 2], 3), ']')
	, paste0('[', round(ci[4, 1], 3), ', ', round(ci[4, 2], 3), ']'))
myTable[, 3] <-  round(pv, 3)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c(2001, 2008, 2014, 2020)
stargazer::stargazer(myTable, summary = FALSE)

# Table 
betas <- c(out01p3$Estimate[1, 'tau.bc'], out08p3$Estimate[1, 'tau.bc'], out14p3$Estimate[1, 'tau.bc'], out20p3$Estimate[1, 'tau.bc'])
SEs <- c(out01p3$Estimate[1, 'se.rb'], out08p3$Estimate[1, 'se.rb'], out14p3$Estimate[1, 'se.rb'], out20p3$Estimate[1, 'se.rb'])
h <- c(out01p3$bws['h', 'left'], out08p3$bws['h', 'left'], out14p3$bws['h', 'left'], out20p3$bws['h', 'left'])
nCo <- c(out01p3$N_h_l[1], out08p3$N_h_l[1], out14p3$N_h_l[1], out20p3$N_h_l[1])
nTr <- c(out01p3$N_h_r[1], out08p3$N_h_r[1], out14p3$N_h_r[1], out20p3$N_h_r[1])
ci <- rbind(out01p3$ci['Robust', ], out08p3$ci['Robust', ], out14p3$ci['Robust', ], out20p3$ci['Robust', ])
pv <- c(out01p3$pv['Robust', ], out08p3$pv['Robust', ], out14p3$pv['Robust', ], out20p3$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 4)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']')
	, paste0('[', round(ci[3, 1], 3), ', ', round(ci[3, 2], 3), ']')
	, paste0('[', round(ci[4, 1], 3), ', ', round(ci[4, 2], 3), ']'))
myTable[, 3] <-  round(pv, 3)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c(2001, 2008, 2014, 2020)
stargazer::stargazer(myTable, summary = FALSE)

# Table
betas <- c(out01p4$Estimate[1, 'tau.bc'], out08p4$Estimate[1, 'tau.bc'], out14p4$Estimate[1, 'tau.bc'], out20p4$Estimate[1, 'tau.bc'])
SEs <- c(out01p4$Estimate[1, 'se.rb'], out08p4$Estimate[1, 'se.rb'], out14p4$Estimate[1, 'se.rb'], out20p4$Estimate[1, 'se.rb'])
h <- c(out01p4$bws['h', 'left'], out08p4$bws['h', 'left'], out14p4$bws['h', 'left'], out20p4$bws['h', 'left'])
nCo <- c(out01p4$N_h_l[1], out08p4$N_h_l[1], out14p4$N_h_l[1], out20p4$N_h_l[1])
nTr <- c(out01p4$N_h_r[1], out08p4$N_h_r[1], out14p4$N_h_r[1], out20p4$N_h_r[1])
ci <- rbind(out01p4$ci['Robust', ], out08p4$ci['Robust', ], out14p4$ci['Robust', ], out20p4$ci['Robust', ])
pv <- c(out01p4$pv['Robust', ], out08p4$pv['Robust', ], out14p4$pv['Robust', ], out20p4$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 4)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']')
	, paste0('[', round(ci[3, 1], 3), ', ', round(ci[3, 2], 3), ']')
	, paste0('[', round(ci[4, 1], 3), ', ', round(ci[4, 2], 3), ']'))
myTable[, 3] <-  round(pv, 3)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c(2001, 2008, 2014, 2020)
stargazer::stargazer(myTable, summary = FALSE)

###########################################################
### DV: Legislative invalid votes in National Elections ###
###########################################################
out01L <- rdrobust(y = franceData01$pctinvalidLeg
		, x = franceData01$zpop
		, p = 1
		, c = 0
		, level = 99		
		, all = TRUE)
out08L <- rdrobust(y = franceData08$pctinvalidLeg
		, x = franceData08$zpop
		, p = 1
		, c = 0
		, level = 99		
		, all = TRUE)
out14L <- rdrobust(y = franceData14$pctinvalidLeg
		, x = franceData14$zpop
		, p = 1
		, c = 0
		, level = 99
		, all = TRUE)
out20L <- rdrobust(y = franceData20$pctinvalidLeg
		, x = franceData20$zpop,
		, p = 1
		, c = 0
		, level = 99			
		, all = TRUE)
summary(out01L)
summary(out08L)
summary(out14L)
summary(out20L)

# Table
betas <- c(out01L$Estimate[1, 'tau.bc'], out08L$Estimate[1, 'tau.bc'], out14L$Estimate[1, 'tau.bc'], out20L$Estimate[1, 'tau.bc'])
SEs <- c(out01L$Estimate[1, 'se.rb'], out08L$Estimate[1, 'se.rb'], out14L$Estimate[1, 'se.rb'], out20L$Estimate[1, 'se.rb'])
h <- c(out01L$bws['h', 'left'], out08L$bws['h', 'left'], out14L$bws['h', 'left'], out20L$bws['h', 'left'])
nCo <- c(out01L$N_h_l[1], out08L$N_h_l[1], out14L$N_h_l[1], out20L$N_h_l[1])
nTr <- c(out01L$N_h_r[1], out08L$N_h_r[1], out14L$N_h_r[1], out20L$N_h_r[1])
ci <- rbind(out01L$ci['Robust', ], out08L$ci['Robust', ], out14L$ci['Robust', ], out20L$ci['Robust', ])
pv <- c(out01L$pv['Robust', ], out08L$pv['Robust', ], out14L$pv['Robust', ], out20L$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 4)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']')
	, paste0('[', round(ci[3, 1], 3), ', ', round(ci[3, 2], 3), ']')
	, paste0('[', round(ci[4, 1], 3), ', ', round(ci[4, 2], 3), ']'))
myTable[, 3] <-  round(pv, 3)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c(2001, 2008, 2014, 2020)
stargazer::stargazer(myTable, summary = FALSE)


############################################################
### DV: Presidential invalid votes in National Elections ###
############################################################
out01P <- rdrobust(y = franceData01$pctinvalidprez
		, x = franceData01$zpop
		, p = 1
		, c = 0
		, level = 99	
		, all = TRUE)
out08P <- rdrobust(y = franceData08$pctinvalidprez
		, x = franceData08$zpop
		, p = 1
		, c = 0
		, level = 99
		, all = TRUE)
out14P <- rdrobust(y = franceData14$pctinvalidprez
		, x = franceData14$zpop
		, p = 1
		, c = 0
		, level = 99				
		, all = TRUE)
out20P <- rdrobust(y = franceData20$pctinvalidprez
		, x = franceData20$zpop,
		, p = 1
		, c = 0
		, level = 99				
		, all = TRUE)
summary(out01P)
summary(out08P)
summary(out14P)
summary(out20P)

# Table 
betas <- c(out01P$Estimate[1, 'tau.bc'], out08P$Estimate[1, 'tau.bc'], out14P$Estimate[1, 'tau.bc'], out20P$Estimate[1, 'tau.bc'])
SEs <- c(out01P$Estimate[1, 'se.rb'], out08P$Estimate[1, 'se.rb'], out14P$Estimate[1, 'se.rb'], out20P$Estimate[1, 'se.rb'])
h <- c(out01P$bws['h', 'left'], out08P$bws['h', 'left'], out14P$bws['h', 'left'], out20P$bws['h', 'left'])
nCo <- c(out01P$N_h_l[1], out08P$N_h_l[1], out14P$N_h_l[1], out20P$N_h_l[1])
nTr <- c(out01P$N_h_r[1], out08P$N_h_r[1], out14P$N_h_r[1], out20P$N_h_r[1])
ci <- rbind(out01P$ci['Robust', ], out08P$ci['Robust', ], out14P$ci['Robust', ], out20P$ci['Robust', ])
pv <- c(out01P$pv['Robust', ], out08P$pv['Robust', ], out14P$pv['Robust', ], out20P$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 4)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']')
	, paste0('[', round(ci[3, 1], 3), ', ', round(ci[3, 2], 3), ']')
	, paste0('[', round(ci[4, 1], 3), ', ', round(ci[4, 2], 3), ']'))
myTable[, 3] <-  round(pv, 4)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c(2001, 2008, 2014, 2020)
stargazer::stargazer(myTable, summary = FALSE)



########################
### DV: Unemployment ###
########################
out01U <- rdrobust(y = franceData01$unem
		, x = franceData01$zpop
		, p = 1
		, c = 0
		, level = 99	
		, all = TRUE)
out08U <- rdrobust(y = franceData08$unem
		, x = franceData08$zpop
		, p = 1
		, c = 0
		, level = 99
		, all = TRUE)
out14U <- rdrobust(y = franceData14$unem
		, x = franceData14$zpop
		, p = 1
		, c = 0
		, level = 99				
		, all = TRUE)
out20U <- rdrobust(y = franceData20$unem
		, x = franceData20$zpop,
		, p = 1
		, c = 0
		, level = 99				
		, all = TRUE)
summary(out01U)
summary(out08U)
summary(out14U)
summary(out20U)

# Table
betas <- c(out01U$Estimate[1, 'tau.bc'], out08U$Estimate[1, 'tau.bc'], out14U$Estimate[1, 'tau.bc'], out20U$Estimate[1, 'tau.bc'])
SEs <- c(out01U$Estimate[1, 'se.rb'], out08U$Estimate[1, 'se.rb'], out14U$Estimate[1, 'se.rb'], out20U$Estimate[1, 'se.rb'])
h <- c(out01U$bws['h', 'left'], out08U$bws['h', 'left'], out14U$bws['h', 'left'], out20U$bws['h', 'left'])
nCo <- c(out01U$N_h_l[1], out08U$N_h_l[1], out14U$N_h_l[1], out20U$N_h_l[1])
nTr <- c(out01U$N_h_r[1], out08U$N_h_r[1], out14U$N_h_r[1], out20U$N_h_r[1])
ci <- rbind(out01U$ci['Robust', ], out08U$ci['Robust', ], out14U$ci['Robust', ], out20U$ci['Robust', ])
pv <- c(out01U$pv['Robust', ], out08U$pv['Robust', ], out14U$pv['Robust', ], out20U$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 4)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']')
	, paste0('[', round(ci[3, 1], 3), ', ', round(ci[3, 2], 3), ']')
	, paste0('[', round(ci[4, 1], 3), ', ', round(ci[4, 2], 3), ']'))
myTable[, 3] <-  round(pv, 4)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c(2001, 2008, 2014, 2020)
stargazer::stargazer(myTable, summary = FALSE)




####################
# Other Treatments #
####################

franceData01$zTemp <- scale(franceData01$lagPop, center = 1000)
out01Placebo <- rdrobust(y = franceData01$pctinvalid
		, x = franceData01$zTemp
		, level = 99
		, p = 1
		, c = 0		
		, all = TRUE)
summary(out01Placebo)

franceData08$zTemp <- scale(franceData08$lagPop, center = 1000)
out08Placebo <- rdrobust(y = franceData08$pctinvalid
		, x = franceData08$zTemp
		, level = 99
		, p = 1
		, c = 0		
		, all = TRUE)
summary(out08Placebo)

franceData14$zTemp <- scale(franceData14$lagPop, center = 3500)
out14Placebo <- rdrobust(y = franceData14$pctinvalid
		, x = franceData14$zTemp
		, level = 99
		, p = 1
		, c = 0		
		, all = TRUE)
summary(out14Placebo)
franceData20$zTemp <- scale(franceData20$lagPop, center = 3500)
out20Placebo <- rdrobust(y = franceData20$pctinvalid
		, x = franceData20$zTemp
		, level = 99
		, p = 1
		, c = 0
		, all = TRUE)
summary(out20Placebo)

pdf('RDDPlotPlacebo0120.pdf')
rdplot(y = franceData01$pctinvalid
	, x = franceData01$zTemp
	, c = 0
	, h = out01Placebo$bws['b', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.09, 0.09)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Invalid Votes')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 3,500)"))
abline(v = 0, col = 'red')
text(x = -0.05, y = 18, 
	labels = paste0("RD Effect = ", round(out01Placebo$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.05, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out01Placebo$ci['Robust', 1], 3), ', ', round(out01Placebo$ci['Robust', 2], 3), ']'))
		, cex = 1)

rdplot(y = franceData08$pctinvalid
	, x = franceData08$zTemp
	, c = 0
	, h = out08Placebo$bws['b', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.05, 0.05)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Invalid Votes')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 3,500)"))
abline(v = 0, col = 'red')
text(x = -0.03, y = 18, 
	labels = paste0("RD Effect = ", round(out08Placebo$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.03, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out08Placebo$ci['Robust', 1], 3), ', ', round(out08Placebo$ci['Robust', 2], 3), ']'))
		, cex = 1)

rdplot(y = franceData14$pctinvalid
	, x = franceData14$zTemp
	, c = 0
	, h = out14Placebo$bws['b', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.14, 0.14)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Invalid Votes')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 3,500)"))
abline(v = 0, col = 'red')
text(x = -0.075, y = 18, 
	labels = paste0("RD Effect = ", round(out14Placebo$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.075, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out14Placebo$ci['Robust', 1], 3), ', ', round(out14Placebo$ci['Robust', 2], 3), ']'))
		, cex = 1)

rdplot(y = franceData20$pctinvalid
	, x = franceData20$zTemp
	, c = 0
	, h = out20Placebo$bws['b', 'left']
	, y.lim = c(0.0, 20)
	, x.lim = c(-0.14, 0.14)
	, binselect = "esmv"
	, p = 1
	, title = ''
	, par = c(mar = c(6, 6, 2, 2))
	, cex = 1.75
	, y.label = c('Invalid Votes')
	, x.label = c("Municipal Population (Re-centered at the Threshold = 3,500)"))
abline(v = 0, col = 'red')
text(x = -0.075, y = 18, 
	labels = paste0("RD Effect = ", round(out20Placebo$Estimate[1, 'tau.bc'],3)), cex = 1)
text(x = -0.075, y = 16, 
	labels = paste0("99% CI = ", paste0('[', round(out20Placebo$ci['Robust', 1], 3), ', ', round(out20Placebo$ci['Robust', 2], 3), ']'))
		, cex = 1)
dev.off()


# Table
betas <- c(out01Placebo$Estimate[1, 'tau.bc'], out08Placebo$Estimate[1, 'tau.bc'], out14Placebo$Estimate[1, 'tau.bc'], out20Placebo$Estimate[1, 'tau.bc'])
SEs <- c(out01Placebo$Estimate[1, 'se.rb'], out08Placebo$Estimate[1, 'se.rb'], out14Placebo$Estimate[1, 'se.rb'], out20Placebo$Estimate[1, 'se.rb'])
h <- c(out01Placebo$bws['h', 'left'], out08Placebo$bws['h', 'left'], out14Placebo$bws['h', 'left'], out20Placebo$bws['h', 'left'])
nCo <- c(out01Placebo$N_h_l[1], out08Placebo$N_h_l[1], out14Placebo$N_h_l[1], out20Placebo$N_h_l[1])
nTr <- c(out01Placebo$N_h_r[1], out08Placebo$N_h_r[1], out14Placebo$N_h_r[1], out20Placebo$N_h_r[1])
ci <- rbind(out01Placebo$ci['Robust', ], out08Placebo$ci['Robust', ], out14Placebo$ci['Robust', ], out20Placebo$ci['Robust', ])
pv <- c(out01Placebo$pv['Robust', ], out08Placebo$pv['Robust', ], out14Placebo$pv['Robust', ], out20Placebo$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 4)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']')
	, paste0('[', round(ci[3, 1], 3), ', ', round(ci[3, 2], 3), ']')
	, paste0('[', round(ci[4, 1], 3), ', ', round(ci[4, 2], 3), ']'))
myTable[, 3] <-  round(pv, 4)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c(2001, 2008, 2014, 2020)
stargazer::stargazer(myTable, summary = FALSE)




###############################
# Difference in Discontinuity #
###############################

# Threshold 1000
france0408 <- subset(france, year %in% c(2008, 2014))
france0408$dc <- paste0(france0408$codedepart, '-', france0408$codecommune)
france0408$zpop1000 <- scale(france0408$lagPop, center = 1000)
france0408$t1000 <- ifelse(france0408$zpop1000 > 0, 1, 0)
france0408$treatment_t_int <- france0408$zpop1000 * france0408$pr
france0408$t1000_int1 <- france0408$zpop1000 * france0408$t1000
france0408$postper <- france0408$year > 2008
france0408$postper_int1 <- france0408$postper * france0408$zpop1000


outDifDistA <- rdrobust(y = france0408$pctinvalid[france0408$year == 2008]
		, x = france0408$zpop1000[france0408$year == 2008]
		, level = 99
		, p = 1
		, c = 0		
		, all = TRUE)
outDifDistB <- rdrobust(y = france0408$pctinvalid[france0408$year == 2014]
		, x = france0408$zpop1000[france0408$year == 2014]
		, level = 99
		, p = 1
		, c = 0		
		, all = TRUE)
bH1 <- (outDifDistA$bws['h', 'left'] + outDifDistB$bws['h', 'left'])/2

m1 <- felm(pctinvalid ~ pr + t1000 + zpop1000 + treatment_t_int + t1000_int1 + postper + postper_int1
	| 0 | 0 | dc
	, data = subset(france0408, abs(zpop1000) < bH1)
	)
summary(m1)$coefficients[2, ]
table(model.frame(m1)$pr)


# Threshold 3500
france0408$zpop3500 <- scale(france0408$lagPop, center = 3500)
france0408$t3500 <- ifelse(france0408$zpop3500 > 0, 1, 0)
france0408$treatment_t_int <- france0408$zpop3500 * france0408$pr
france0408$t3500_int1 <- france0408$zpop3500 * france0408$t3500
france0408$postper <- france0408$year > 2008
france0408$postper_int1 <- france0408$postper * france0408$zpop3500

outDifDistA <- rdrobust(y = france0408$pctinvalid[france0408$year == 2008]
		, x = france0408$zpop3500[france0408$year == 2008]
		, level = 99
		, p = 1
		, c = 0	
		, all = TRUE)
outDifDistB <- rdrobust(y = france0408$pctinvalid[france0408$year == 2014]
		, x = france0408$zpop3500[france0408$year == 2014]
		, level = 99
		, p = 1
		, c = 0		
		, all = TRUE)
bH2 <- (outDifDistA$bws['h', 'left'] + outDifDistB$bws['h', 'left'])/2
m2 <- felm(pctinvalid ~ pr + t3500 + zpop3500 + treatment_t_int + t3500_int1 + postper + postper_int1
	| 0 | 0 | dc
	, data = subset(france0408, abs(zpop3500) < bH2)
	)
summary(m2)$coefficients[2, ]
table(model.frame(m2)$pr)





######################
### RDD - Fuzzy ######
######################
franceData01$pr <- ifelse(franceData01$zpop > 0, 1, 0)
out01f <- rdrobust(y = franceData01$pctinvalid
		, x = franceData01$zpop
		, fuzzy = franceData01$pr
		, p = 1
		, c = 0
		, level = 99	
		, all = TRUE)
out08f <- rdrobust(y = franceData08$pctinvalid
		, x = franceData08$zpop
		, fuzzy = franceData08$pr
		, p = 1
		, c = 0
		, level = 99
		, all = TRUE)
out14f <- rdrobust(y = franceData14$pctinvalid
		, x = franceData14$zpop
		, fuzzy = franceData14$pr
		, p = 1
		, c = 0
		, level = 99				
		, all = TRUE)
out20f <- rdrobust(y = franceData20$pctinvalid
		, x = franceData20$zpop
		, fuzzy = franceData20$pr
		, p = 1
		, c = 0
		, level = 99				
		, all = TRUE)
summary(out01f)
summary(out08f)
summary(out14f)
summary(out20f)

betas <- c(out01f$Estimate[1, 'tau.bc'], out08f$Estimate[1, 'tau.bc'], out14f$Estimate[1, 'tau.bc'], out20f$Estimate[1, 'tau.bc'])
SEs <- c(out01f$Estimate[1, 'se.rb'], out08f$Estimate[1, 'se.rb'], out14f$Estimate[1, 'se.rb'], out20f$Estimate[1, 'se.rb'])
h <- c(out01f$bws['h', 'left'], out08f$bws['h', 'left'], out14f$bws['h', 'left'], out20f$bws['h', 'left'])
nCo <- c(out01f$N_h_l[1], out08f$N_h_l[1], out14f$N_h_l[1], out20f$N_h_l[1])
nTr <- c(out01f$N_h_r[1], out08f$N_h_r[1], out14f$N_h_r[1], out20f$N_h_r[1])
ci <- rbind(out01f$ci['Robust', ], out08f$ci['Robust', ], out14f$ci['Robust', ], out20f$ci['Robust', ])
pv <- c(out01f$pv['Robust', ], out08f$pv['Robust', ], out14f$pv['Robust', ], out20f$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 4)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']')
	, paste0('[', round(ci[3, 1], 3), ', ', round(ci[3, 2], 3), ']')
	, paste0('[', round(ci[4, 1], 3), ', ', round(ci[4, 2], 3), ']'))
myTable[, 3] <-  round(pv, 3)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c(2001, 2008, 2014, 2020)
stargazer::stargazer(myTable, summary = FALSE)


######################################
########### RDD for Turnout ##########
######################################

out01Turn <- rdrobust(y = franceData01$turnout
		, x = franceData01$zpop
		, p = 1
		, c = 0
		, level = 99
		, all = TRUE)
out08Turn <- rdrobust(y = franceData08$turnout
		, x = franceData08$zpop
		, p = 1
		, c = 0
		, level = 99
		, all = TRUE)
out14Turn <- rdrobust(y = franceData14$turnout
		, x = franceData14$zpop
		, p = 1
		, c = 0
		, level = 99		
		, all = TRUE)
out20Turn <- rdrobust(y = franceData20$turnout
		, x = franceData20$zpop
		, p = 1
		, c = 0
		, level = 99		
		, all = TRUE)
summary(out01Turn)
summary(out08Turn)
summary(out14Turn)
summary(out20Turn)

betas <- c(out01Turn$Estimate[1, 'tau.bc'], out08Turn$Estimate[1, 'tau.bc'], out14Turn$Estimate[1, 'tau.bc'], out20Turn$Estimate[1, 'tau.bc'])
SEs <- c(out01Turn$Estimate[1, 'se.rb'], out08Turn$Estimate[1, 'se.rb'], out14Turn$Estimate[1, 'se.rb'], out20Turn$Estimate[1, 'se.rb'])
h <- c(out01Turn$bws['h', 'left'], out08Turn$bws['h', 'left'], out14Turn$bws['h', 'left'], out20Turn$bws['h', 'left'])
nCo <- c(out01Turn$N_h_l[1], out08Turn$N_h_l[1], out14Turn$N_h_l[1], out20Turn$N_h_l[1])
nTr <- c(out01Turn$N_h_r[1], out08Turn$N_h_r[1], out14Turn$N_h_r[1], out20Turn$N_h_r[1])
ci <- rbind(out01Turn$ci['Robust', ], out08Turn$ci['Robust', ], out14Turn$ci['Robust', ], out20Turn$ci['Robust', ])
pv <- c(out01Turn$pv['Robust', ], out08Turn$pv['Robust', ], out14Turn$pv['Robust', ], out20Turn$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 4)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']')
	, paste0('[', round(ci[3, 1], 3), ', ', round(ci[3, 2], 3), ']')
	, paste0('[', round(ci[4, 1], 3), ', ', round(ci[4, 2], 3), ']'))
myTable[, 3] <-  round(pv, 3)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c(2001, 2008, 2014, 2020)
stargazer::stargazer(myTable, summary = FALSE)


################################################################
####################### Descriptive Stats ######################
################################################################

# We calculate the pct_invalid by:
# (1 - validvotes/totalvotes) * 100
# However, there are a few cases in which the blanknull votes + valid votes > total votes
# This seems to be an error in the original data available on the Minstery of Interieur Website
# Here is an example:
subset(franceData08, codecommune == '270' & codedepart == 51)
# https://www.interieur.gouv.fr/Elections/Les-resultats/Municipales/elecresult__municipales_2008/(path)/municipales_2008/051/051270.html 
# We have pct_invalid = 0, but blanknull = 160, valid votes = 161, and totalvotes = 161
# We don't try to correct these values. We decided to use our measure pct_invalid


toTable <- matrix(NA, ncol = 7, nrow = 12)
toTable[1, ] <- c(length(franceData01$pctinvalid), summary(franceData01$pctinvalid))
toTable[2, ] <- c(length(franceData01$pctinvalid[franceData01$zpop < 0]), summary(franceData01$pctinvalid[franceData01$zpop < 0]))
toTable[3, ] <- c(length(franceData01$pctinvalid[franceData01$zpop >= 0]), summary(franceData01$pctinvalid[franceData01$zpop >= 0]))

toTable[4, ] <- c(length(franceData08$pctinvalid), summary(franceData08$pctinvalid))
toTable[5, ] <- c(length(franceData08$pctinvalid[franceData08$zpop < 0]), summary(franceData08$pctinvalid[franceData08$zpop < 0]))
toTable[6, ] <- c(length(franceData08$pctinvalid[franceData08$zpop >= 0]), summary(franceData08$pctinvalid[franceData08$zpop >= 0]))

toTable[7, ] <- c(length(franceData14$pctinvalid), summary(franceData14$pctinvalid))
toTable[8, ] <- c(length(franceData14$pctinvalid[franceData14$zpop < 0]), summary(franceData14$pctinvalid[franceData14$zpop < 0]))
toTable[9, ] <- c(length(franceData14$pctinvalid[franceData14$zpop >= 0]), summary(franceData14$pctinvalid[franceData14$zpop >= 0]))

toTable[10, ] <- c(length(franceData20$pctinvalid), summary(franceData20$pctinvalid))
toTable[11, ] <- c(length(franceData20$pctinvalid[franceData20$zpop < 0]), summary(franceData20$pctinvalid[franceData20$zpop < 0]))
toTable[12, ] <- c(length(franceData20$pctinvalid[franceData20$zpop >= 0]), summary(franceData20$pctinvalid[franceData20$zpop >= 0]))

rownames(toTable) <- c('Full Sample'
	, 'Below the Threhsold'
	, 'Above the Threshild'
	, 'Full Sample'
	, 'Below the Threhsold'
	, 'Above the Threshild'
	, 'Full Sample'
	, 'Below the Threhsold'
	, 'Above the Threshild'
	, 'Full Sample'
	, 'Below the Threhsold'
	, 'Above the Threshild')

colnames(toTable) <- c('N', names(summary(franceData01$pctinvalid)))
stargazer::stargazer(toTable)



###########################################################
########### RDD for Null and Blank Votes in 2020 ##########
###########################################################

# This information only exists for 2020
franceData20$pct_blank <- (franceData20$blank/franceData20$totalvotes) * 100
franceData20$pct_null <- (franceData20$null/franceData20$totalvotes) * 100

out20Blank <- rdrobust(y = franceData20$pct_blank
		, x = franceData20$zpop
		, p = 1
		, c = 0
		, level = 99		
		, all = TRUE)
out20Null <- rdrobust(y = franceData20$pct_null
		, x = franceData20$zpop
		, p = 1
		, c = 0
		, level = 99		
		, all = TRUE)
summary(out20Blank)
summary(out20Null)

betas <- c(out20Blank$Estimate[1, 'tau.bc'], out20Null$Estimate[1, 'tau.bc'])
SEs <- c(out20Blank$Estimate[1, 'se.rb'], out20Null$Estimate[1, 'se.rb'])
h <- c(out20Blank$bws['h', 'left'], out20Null$bws['h', 'left'])
nCo <- c(out20Blank$N_h_l[1], out20Null$N_h_l[1])
nTr <- c(out20Blank$N_h_r[1], out20Null$N_h_r[1])
ci <- rbind(out20Blank$ci['Robust', ], out20Null$ci['Robust', ])
pv <- c(out20Blank$pv['Robust', ], out20Null$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 2)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']'))
myTable[, 3] <-  round(pv, 3)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c('% of Blank', '% of Null')
stargazer::stargazer(myTable, summary = FALSE)


###########################################################
### RDD for BNS votes in the Second Round 2008 and 2014 ###
###########################################################


load(file = 'france14Final2Round.RData')
load(file = 'france08Final2Round.RData')

# Invalid Second Round
invR2_08 <- rdrobust(y = franceData08Both$pctinvalid_R2
		, x = franceData08Both$zpop
		, p = 1
		, c = 0
		, level = 99
		, all = TRUE)
summary(invR2_08)

invR2_14 <- rdrobust(y = franceData14Both$pctinvalid_R2
		, x = franceData14Both$zpop
		, p = 1
		, c = 0
		, level = 99
		, all = TRUE)
summary(invR2_14)

betas <- c(invR2_08$Estimate[1, 'tau.bc'], invR2_14$Estimate[1, 'tau.bc'])
SEs <- c(invR2_08$Estimate[1, 'se.rb'], invR2_14$Estimate[1, 'se.rb'])
h <- c(invR2_08$bws['h', 'left'], invR2_14$bws['h', 'left'])
nCo <- c(invR2_08$N_h_l[1], invR2_14$N_h_l[1])
nTr <- c(invR2_08$N_h_r[1], invR2_14$N_h_r[1])
ci <- rbind(invR2_08$ci['Robust', ], invR2_14$ci['Robust', ])
pv <- c(invR2_08$pv['Robust', ], invR2_14$pv['Robust', ])
myTable <- matrix(NA, ncol = 6, nrow = 2)
myTable[, 1] <- round(betas, 3)
myTable[, 2] <- c(paste0('[', round(ci[1, 1], 3), ', ', round(ci[1, 2], 3), ']')
	, paste0('[', round(ci[2, 1], 3), ', ', round(ci[2, 2], 3), ']'))
myTable[, 3] <-  round(pv, 3)
myTable[, 4] <-  round(h, 3)
myTable[, 5] <-  nCo
myTable[, 6] <-  nTr
colnames(myTable) <- c('Estimate', '99CI', 'p-value', 'h', 'nco', 'ntr')
rownames(myTable) <- c('2008', '2014')
stargazer::stargazer(myTable, summary = FALSE)



